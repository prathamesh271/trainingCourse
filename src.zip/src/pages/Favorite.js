function Favorite(){
    return (
        <div>
            <h1>Favorite</h1>
        </div>
    )
}

export default Favorite;