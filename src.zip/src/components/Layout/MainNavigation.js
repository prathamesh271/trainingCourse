import { Link } from 'react-router-dom';
import './MainNavigation.css';

function MainNavigation(){
    return(
        <header className="header">
            <h2 className="logo">React Meetups</h2>
            <nav className="nav">
                <ul className="nav-ul">
                    <li className="nav-item">
                        <Link to="/" className="nav-link">All Meetups</Link>
                    </li>
                    <li className="nav-item">
                        <Link to="/new-meetups" className="nav-link">New Meetups</Link>
                    </li>
                    <li className="nav-item">
                        <Link to="/favorites" className="nav-link">Favorite</Link>
                    </li>
                </ul>
            </nav>
        </header>
    )
}
export default MainNavigation;