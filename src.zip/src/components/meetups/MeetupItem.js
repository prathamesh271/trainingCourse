import Card from '../ui/Card';
import './meetupItem.css';

function MeetupItem(props){
    return(
        <div> 
            <Card> 
                <h2 className="title">{props.title}</h2>
                <address className="address">{props.address}</address>
                <div className="description">{props.description}</div>
                <div className="">
                    <button className="btn favorite-btn">To Favorite</button>
                </div>
            </Card>
        </div>
    )
}

export default MeetupItem;