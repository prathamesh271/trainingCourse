import MeetupList from "../components/meetups/MeetupList";

const DUMMY_DATA = [
    {
        id: 'm1',
        title: 'This is first meetups',
        address: 'Pune',
        description: 'This is first meetups',
    },
    {
        id: 'm2',
        title: 'This is second meetups',
        address: 'Mumbai',
        description: 'This is second meetups',
    },    
    {
        id: 'm3',
        title: 'This is third meetups',
        address: 'Banglore',
        description: 'This is third meetups',
    }
]

function AllMeetups(){
    return (
        <section className="container">
            <h1>All Meetups</h1>
            <MeetupList meetups={DUMMY_DATA}/>
        </section>
    )
}

export default AllMeetups;